<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SavingsServices;


class SavingsController extends Controller
{
    //
}
