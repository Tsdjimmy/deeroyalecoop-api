<?php

namespace App\services;
use App\Models\User;
use App\Models\Savings;

class SavingsServices
{

}
